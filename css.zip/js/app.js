
   function callNav(){
     document.getElementById("navCustom").classList.add("active");
     document.getElementById("closeBtn").classList.add("active");
   }

   function closeNav(){
     document.getElementById("navCustom").classList.remove("active")
     document.getElementById("closeBtn").classList.remove("active");
   }

  

              
 


 
 